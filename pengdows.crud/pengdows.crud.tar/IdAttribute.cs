namespace pengdows.crud;

[AttributeUsage(AttributeTargets.Property)]
public sealed class IdAttribute : Attribute
{
}