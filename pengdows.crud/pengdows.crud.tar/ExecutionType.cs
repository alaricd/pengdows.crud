namespace pengdows.crud;

public enum ExecutionType
{
    Read,
    Write
}