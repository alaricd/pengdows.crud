public interface IAsyncTestProvider
{
    Task RunTest();
}