namespace pengdows.crud;

public enum ProcWrappingStyle
{
    None = 0,
    Call,
    Exec,
    PostgreSQL,
    Oracle,
    ExecuteProcedure
}