namespace pengdows.crud.enums;

public enum EnumParseFailureMode
{
    Throw,
    SetNullAndLog,
    SetDefaultValue // Optional
}