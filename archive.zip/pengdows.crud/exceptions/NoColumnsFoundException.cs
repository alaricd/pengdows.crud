namespace pengdows.crud;

public class NoColumnsFoundException : Exception
{
    public NoColumnsFoundException(string message) : base(message)
    {
    }
}