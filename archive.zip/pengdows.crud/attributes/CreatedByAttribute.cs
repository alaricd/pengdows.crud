namespace pengdows.crud.attributes;

[AttributeUsage(AttributeTargets.Property)]
public class CreatedByAttribute : Attribute
{
}