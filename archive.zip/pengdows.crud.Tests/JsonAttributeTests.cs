using Xunit;

namespace pengdows.crud.Tests
{
    public class JsonAttributeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for JsonAttribute.cs
            Assert.True(true);
        }
    }
}
