using Xunit;

namespace pengdows.crud.Tests
{
    public class PrimaryKeyOnRowIdColumnsTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for PrimaryKeyOnRowIdColumns.cs
            Assert.True(true);
        }
    }
}
