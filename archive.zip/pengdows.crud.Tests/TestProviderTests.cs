using Xunit;

namespace pengdows.crud.Tests
{
    public class TestProviderTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for TestProvider
            Assert.True(true);
        }
    }
}
