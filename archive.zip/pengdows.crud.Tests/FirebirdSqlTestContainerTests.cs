using Xunit;

namespace pengdows.crud.Tests
{
    public class FirebirdSqlTestContainerTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for FirebirdSqlTestContainer
            Assert.True(true);
        }
    }
}
