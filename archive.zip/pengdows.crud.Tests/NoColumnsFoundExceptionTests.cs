using Xunit;

namespace pengdows.crud.Tests
{
    public class NoColumnsFoundExceptionTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for NoColumnsFoundException.cs
            Assert.True(true);
        }
    }
}
