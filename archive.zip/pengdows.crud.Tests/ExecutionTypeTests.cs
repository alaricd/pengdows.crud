using Xunit;

namespace pengdows.crud.Tests
{
    public class ExecutionTypeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for ExecutionType.cs
            Assert.True(true);
        }
    }
}
