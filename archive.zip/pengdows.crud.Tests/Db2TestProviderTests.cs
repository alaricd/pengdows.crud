using Xunit;

namespace pengdows.crud.Tests
{
    public class Db2TestProviderTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for Db2TestProvider
            Assert.True(true);
        }
    }
}
