using Xunit;

namespace pengdows.crud.Tests
{
    public class NonUpdateableAttributeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for NonUpdateableAttribute.cs
            Assert.True(true);
        }
    }
}
