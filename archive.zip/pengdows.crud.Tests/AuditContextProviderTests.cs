using Xunit;

namespace pengdows.crud.Tests
{
    public class AuditContextProviderTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for AuditContextProvider
            Assert.True(true);
        }
    }
}
