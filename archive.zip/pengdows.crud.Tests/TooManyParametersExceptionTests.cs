using Xunit;

namespace pengdows.crud.Tests
{
    public class TooManyParametersExceptionTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for TooManyParametersException.cs
            Assert.True(true);
        }
    }
}
