using Xunit;

namespace pengdows.crud.Tests
{
    public class TooManyColumnsTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for TooManyColumns.cs
            Assert.True(true);
        }
    }
}
