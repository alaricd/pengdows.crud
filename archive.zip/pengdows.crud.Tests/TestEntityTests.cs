using Xunit;

namespace pengdows.crud.Tests
{
    public class TestEntityTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for TestEntity
            Assert.True(true);
        }
    }
}
