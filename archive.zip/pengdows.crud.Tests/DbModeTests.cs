using Xunit;

namespace pengdows.crud.Tests
{
    public class DbModeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for DbMode.cs
            Assert.True(true);
        }
    }
}
