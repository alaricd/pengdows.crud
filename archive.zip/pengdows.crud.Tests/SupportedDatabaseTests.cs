using Xunit;

namespace pengdows.crud.Tests
{
    public class SupportedDatabaseTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for SupportedDatabase.cs
            Assert.True(true);
        }
    }
}
