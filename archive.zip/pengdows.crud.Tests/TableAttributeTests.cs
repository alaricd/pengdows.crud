using Xunit;

namespace pengdows.crud.Tests
{
    public class TableAttributeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for TableAttribute.cs
            Assert.True(true);
        }
    }
}
