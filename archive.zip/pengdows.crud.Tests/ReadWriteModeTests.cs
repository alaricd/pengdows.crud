using Xunit;

namespace pengdows.crud.Tests
{
    public class ReadWriteModeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for ReadWriteMode.cs
            Assert.True(true);
        }
    }
}
