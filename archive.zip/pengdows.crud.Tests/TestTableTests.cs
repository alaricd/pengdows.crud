using Xunit;

namespace pengdows.crud.Tests
{
    public class TestTableTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for TestTable
            Assert.True(true);
        }
    }
}
