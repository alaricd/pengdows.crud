using Xunit;

namespace pengdows.crud.Tests
{
    public class ColumnAttributeTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for ColumnAttribute.cs
            Assert.True(true);
        }
    }
}
