using Xunit;

namespace pengdows.crud.Tests
{
    public class ConnectionFailedExceptionTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for ConnectionFailedException.cs
            Assert.True(true);
        }
    }
}
