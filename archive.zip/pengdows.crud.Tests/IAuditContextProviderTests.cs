using Xunit;

namespace pengdows.crud.Tests
{
    public class IAuditContextProviderTests
    {
        [Fact]
        public void PlaceholderTest()
        {
            // TODO: Implement tests for IAuditContextProvider.cs
            Assert.True(true);
        }
    }
}
