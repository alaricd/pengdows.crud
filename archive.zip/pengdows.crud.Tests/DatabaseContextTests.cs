// using Xunit;
//
// namespace pengdows.crud.Tests;
//
// public class DatabaseContextTests
// {
//     [Fact]
//     public void WrapObjectName_UsesDoubleQuotes()
//     {
//         var context = new FakeDatabaseContext();
//         Assert.Equal("\"Table\"", context.WrapObjectName("Table"));
//     }
//
//     [Fact]
//     public void CompositeSeparator_IsValid()
//     {
//         var context = new FakeDatabaseContext();
//         Assert.Equal(".", context.DataSourceInfo.CompositeIdentifierSeparator);
//     }
// }